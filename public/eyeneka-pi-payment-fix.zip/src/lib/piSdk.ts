export const PI_OAUTH_CLIENT_ID = "xWHNaUUWdRg4mpkSUSlfh0NGvLF1iOrcEDivLTC";
export const PI_APP_REDIRECT_URL = "https://eyeneka.vercel.app/";
export const PI_AUTH_SCOPES: ["username", "payments"] = ["username", "payments"];
export const PI_SIGNIN_ERROR_MESSAGE = "Pi Sign-In failed. Try again in Pi Browser.";
export const PI_SDK_NOT_FOUND_MESSAGE = "Open via Pi App address in Pi Browser";
export const PI_BROWSER_REQUIRED_MESSAGE = PI_SDK_NOT_FOUND_MESSAGE;
export const PI_CANCELLED_MESSAGE = "Payment cancelled. No Pi was taken.";
export const PI_POPUP_TIMEOUT_MESSAGE =
  "Pi popup did not appear. Open Eyeneka via its Pi address https://eyenekaurr8852.pinet.com in Pi Browser (not vercel.app), log into Pi, unlock Pi Wallet, then tap Connect Pi.";

export class PiPaymentCancelledError extends Error {
  constructor(message = PI_CANCELLED_MESSAGE) {
    super(message);
    this.name = "PiPaymentCancelledError";
  }
}

export interface PiAuthResult {
  connected: boolean;
  username: string;
  uid: string;
  accessToken?: string;
  kycVerified: boolean;
  inPiBrowser: boolean;
}

export interface PiAuthAttempt {
  success: boolean;
  result: PiAuthResult | null;
  error?: string;
  timedOut?: boolean;
}

export interface PiPaymentPayload {
  amount: number;
  memo: string;
  metadata: Record<string, string | number | boolean>;
}

export interface PiPaymentReceipt {
  paymentId: string;
  txHash: string;
  amount: number;
  memo: string;
  mode: "testnet-sdk";
  status: "Confirmed";
  grantIssued: boolean;
}

interface IncompletePiPayment {
  identifier?: string;
  amount?: number;
  memo?: string;
  metadata?: Record<string, unknown>;
  transaction?: { txid?: string };
  status?: {
    developer_approved?: boolean;
    developer_completed?: boolean;
    cancelled?: boolean;
  };
}

interface WindowPi {
  init: (config: { version: string; sandbox?: boolean }) => Promise<void> | void;
  authenticate: (
    scopes: string[],
    onIncompletePaymentFound?: (payment: IncompletePiPayment) => void
  ) => Promise<{
    accessToken?: string;
    user?: { uid?: string; username?: string; kyc?: boolean };
  }>;
  getIncompletePayments?: () => Promise<IncompletePiPayment[]>;
  createPayment: (
    paymentData: PiPaymentPayload,
    callbacks: {
      onReadyForServerApproval: (paymentId: string) => void | Promise<void>;
      onReadyForServerCompletion: (paymentId: string, txid: string) => void | Promise<void>;
      onCancel: (paymentId: string) => void;
      onError: (error: Error, payment?: unknown) => void;
    }
  ) => void;
  Ads?: {
    showAd: (adType: "interstitial" | "rewarded") => Promise<{ result: string; adId?: string }>;
  };
}

declare global {
  interface Window {
    Pi?: WindowPi;
  }
}

const PI_WALLET_TIMEOUT_MS = 60000;

let alreadyInit = false;
let initInFlight: Promise<boolean> | null = null;
let lastInitError: string | null = null;

let inMemorySessionToken: string | null = null;
let inMemoryUser: { uid: string; username: string } | null = null;
let paymentScopeAuthenticated = false;

let authInFlight: Promise<PiAuthAttempt> | null = null;
let incompleteHandlingInFlight: Promise<void> | null = null;

const approvedOrInFlightPaymentIds = new Set<string>();
const completedOrInFlightPaymentIds = new Set<string>();

export function getSessionToken(): string | null {
  return inMemorySessionToken;
}

export function getVerifiedSessionUser(): { uid: string; username: string } | null {
  return inMemoryUser;
}

export function isPiConnectedSession(): boolean {
  return Boolean(inMemoryUser?.username && paymentScopeAuthenticated);
}

export function getLastInitError(): string | null {
  return lastInitError;
}

export async function logoutPiSession(): Promise<void> {
  const token = inMemorySessionToken;
  inMemorySessionToken = null;
  inMemoryUser = null;
  paymentScopeAuthenticated = false;
  if (!token) return;
  try {
    await fetch("/api/pi/logout", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  } catch {
    // Best-effort server revocation
  }
}

export function isPiBrowserAvailable(): boolean {
  return typeof window !== "undefined" && typeof window.Pi !== "undefined";
}

export function isRealPiBrowserEnvironment(): boolean {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return false;
  }
  const ua = navigator.userAgent || "";
  const ref = typeof document !== "undefined" ? document.referrer || "" : "";
  const isPiContext =
    /PiBrowser|MinePi|PiNetwork|AppStudio/i.test(ua) ||
    /(piappengine\.com|minepi\.com|pinet\.com|pi\.app)/i.test(ref);
  return isPiContext && typeof window.Pi !== "undefined";
}

function isPreviewOrLocalHost(): boolean {
  if (typeof window === "undefined") return false;
  const host = window.location.hostname || "";
  return host === "localhost" || host === "127.0.0.1" || host.endsWith(".run.app");
}

export async function initPiSdk(): Promise<boolean> {
  if (typeof window === "undefined" || !window.Pi) {
    lastInitError = PI_SDK_NOT_FOUND_MESSAGE;
    console.log("[EYENEKA Pi] Pi.init skipped: window.Pi undefined");
    return false;
  }
  if (isPreviewOrLocalHost() && !isRealPiBrowserEnvironment()) {
    lastInitError = PI_SDK_NOT_FOUND_MESSAGE;
    console.log("[EYENEKA Pi] Preview host outside Pi Browser; skipping Pi.init");
    return false;
  }
  if (alreadyInit) {
    return true;
  }
  if (initInFlight) {
    return await initInFlight;
  }
  initInFlight = (async () => {
    try {
      const sdkInitPromise = Promise.resolve(window.Pi!.init({ version: "2.0" }));
      sdkInitPromise.catch(() => {
        // Swallow delayed SDK 120s messaging promise rejection when outside Pi Browser
      });
      await withTimeout(
        sdkInitPromise,
        15000,
        () => new Error("Pi.init timed out after 15s. " + PI_SDK_NOT_FOUND_MESSAGE)
      );
      alreadyInit = true;
      lastInitError = null;
      console.log("[EYENEKA Pi] Pi.init result: success (version 2.0)");
      return true;
    } catch (err) {
      const msg = err instanceof Error && err.message ? err.message : String(err);
      lastInitError = msg;
      console.log("[EYENEKA Pi] Pi.init skipped/unavailable:", msg);
      return false;
    } finally {
      initInFlight = null;
    }
  })();
  return await initInFlight;
}

class AuthTimeoutError extends Error {
  constructor(message = PI_POPUP_TIMEOUT_MESSAGE) {
    super(message);
    this.name = "AuthTimeoutError";
  }
}

function withTimeout<T>(promise: Promise<T>, ms: number, errFactory: () => Error): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(errFactory());
    }, ms);
    promise.then(
      (val) => {
        window.clearTimeout(timer);
        resolve(val);
      },
      (err) => {
        window.clearTimeout(timer);
        reject(err);
      }
    );
  });
}

async function postJsonWithDetails(
  url: string,
  payload: Record<string, unknown>,
  bearerToken?: string | null,
  timeoutMs = 20000
): Promise<{ status: number; ok: boolean; data: Record<string, unknown> }> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (bearerToken) {
    headers.Authorization = `Bearer ${bearerToken}`;
  }
  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timer = controller ? window.setTimeout(() => controller.abort(), timeoutMs) : null;
  try {
    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
      ...(controller ? { signal: controller.signal } : {}),
    });
    const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    return { status: response.status, ok: response.ok, data };
  } catch (err: unknown) {
    if (err instanceof Error && err.name === "AbortError") {
      throw new Error(`Request to ${url} timed out after ${Math.round(timeoutMs / 1000)}s.`);
    }
    throw err;
  } finally {
    if (timer !== null) {
      window.clearTimeout(timer);
    }
  }
}

function extractDetailsText(rawDetails: unknown): string {
  if (!rawDetails) return "";
  if (typeof rawDetails === "string") return rawDetails.trim();
  if (typeof rawDetails === "object") {
    const obj = rawDetails as Record<string, unknown>;
    if (typeof obj.error_message === "string" && obj.error_message.trim()) {
      return obj.error_message.trim();
    }
    if (typeof obj.message === "string" && obj.message.trim()) {
      return obj.message.trim();
    }
    if (typeof obj.error === "string" && obj.error.trim()) {
      return obj.error.trim();
    }
    try {
      const serialized = JSON.stringify(obj);
      return serialized === "{}" ? "" : serialized;
    } catch {
      return "";
    }
  }
  return String(rawDetails);
}

function formatServerFailure(
  prefix: string,
  res: { status: number; data: Record<string, unknown> },
  fallback: string
): string {
  const piStatus =
    typeof res.data.piStatus === "number" ? res.data.piStatus : res.status;
  const detailsText = extractDetailsText(res.data.details);
  const errMsg =
    (typeof res.data.error === "string" && res.data.error.trim()) || fallback;
  if (detailsText) {
    return `${prefix}: ${piStatus} - ${detailsText}`;
  }
  return `${prefix}: ${piStatus} - ${errMsg}`;
}

async function exchangeAccessTokenForSession(accessToken: string): Promise<{
  sessionToken: string;
  user: { uid: string; username: string };
}> {
  const res = await withTimeout(
    postJsonWithDetails("/api/pi/login", { accessToken }),
    15000,
    () => new Error("Server /api/pi/login verification timed out after 15s.")
  );
  const userObj = res.data.user as { uid?: unknown; username?: unknown } | undefined;
  const sessionToken = typeof res.data.sessionToken === "string" ? res.data.sessionToken : "";
  const uid = typeof userObj?.uid === "string" ? userObj.uid : "";
  const username =
    typeof userObj?.username === "string" ? userObj.username.replace(/^@/, "") : "";

  if (!res.ok || !sessionToken || !uid || !username) {
    const serverErr =
      (typeof res.data.error === "string" && res.data.error) || PI_SIGNIN_ERROR_MESSAGE;
    throw new Error(serverErr);
  }

  inMemorySessionToken = sessionToken;
  inMemoryUser = { uid, username };
  return { sessionToken, user: { uid, username } };
}

export async function handleIncompletePayment(payment: IncompletePiPayment): Promise<void> {
  if (!payment?.identifier) return;
  const paymentId = payment.identifier;
  const idPrefix = paymentId.slice(0, 8);
  const txid = payment.transaction?.txid;
  console.log("[EYENEKA Pi] onIncompletePaymentFound:", {
    paymentIdPrefix: idPrefix,
    hasTxid: Boolean(txid),
    status: payment.status,
  });

  const run = (async () => {
    try {
      if (txid && !payment.status?.developer_completed) {
        if (completedOrInFlightPaymentIds.has(paymentId)) {
          return;
        }
        completedOrInFlightPaymentIds.add(paymentId);
        try {
          const completeRes = await postJsonWithDetails("/api/pi/complete", {
            paymentId,
            txid,
          });
          console.log("[EYENEKA Pi] Incomplete /api/pi/complete response:", {
            paymentIdPrefix: idPrefix,
            status: completeRes.status,
            ok: completeRes.ok,
          });
          if (!completeRes.ok || completeRes.data.ok === false) {
            completedOrInFlightPaymentIds.delete(paymentId);
          }
        } catch (err) {
          completedOrInFlightPaymentIds.delete(paymentId);
          throw err;
        }
        return;
      }

      if (!payment.status?.developer_completed && !payment.status?.cancelled) {
        const cancelRes = await postJsonWithDetails("/api/pi/cancel", { paymentId });
        console.log("[EYENEKA Pi] Incomplete /api/pi/cancel response:", {
          paymentIdPrefix: idPrefix,
          status: cancelRes.status,
          ok: cancelRes.ok,
        });
      }
    } catch (err) {
      console.log("[EYENEKA Pi] Incomplete payment handler error:", err);
    }
  })();

  incompleteHandlingInFlight = run;
  try {
    await run;
  } finally {
    if (incompleteHandlingInFlight === run) {
      incompleteHandlingInFlight = null;
    }
  }
}

export async function resumeIncompletePayments(): Promise<number> {
  if (!isPiBrowserAvailable()) {
    return 0;
  }
  const sdkReady = await initPiSdk();
  if (!sdkReady || !window.Pi) {
    return 0;
  }

  let resumed = 0;
  if (
    isRealPiBrowserEnvironment() &&
    typeof window.Pi.getIncompletePayments === "function"
  ) {
    try {
      const pending = await window.Pi.getIncompletePayments();
      if (Array.isArray(pending)) {
        for (const p of pending) {
          void handleIncompletePayment(p);
          resumed += 1;
        }
      }
    } catch {
      // Ignore if Pi Browser session is not yet authenticated
    }
  }

  try {
    const res = await fetch("/api/pi/incomplete", { method: "POST" });
    if (res.ok) {
      const data = (await res.json().catch(() => ({}))) as { resumedCount?: number };
      if (typeof data.resumedCount === "number") {
        resumed += data.resumedCount;
      }
    }
  } catch {
    // Ignore network unavailability
  }

  return resumed;
}

export async function authenticateWithPiSdk(options?: {
  fresh?: boolean;
}): Promise<PiAuthAttempt> {
  if (typeof window === "undefined" || !window.Pi) {
    return {
      success: false,
      result: null,
      error: PI_SDK_NOT_FOUND_MESSAGE,
    };
  }

  if (options?.fresh && !authInFlight) {
    inMemoryUser = null;
    inMemorySessionToken = null;
    paymentScopeAuthenticated = false;
  }

  if (inMemoryUser?.username && paymentScopeAuthenticated) {
    return {
      success: true,
      result: {
        connected: true,
        username: inMemoryUser.username,
        uid: inMemoryUser.uid,
        kycVerified: true,
        inPiBrowser: true,
      },
    };
  }

  if (authInFlight) {
    console.log("[EYENEKA Pi] Returning existing in-flight Pi.authenticate promise");
    return await authInFlight;
  }

  authInFlight = (async (): Promise<PiAuthAttempt> => {
    const sdkReady = await initPiSdk();
    if (!sdkReady || !window.Pi) {
      return {
        success: false,
        result: null,
        error: lastInitError || PI_SDK_NOT_FOUND_MESSAGE,
      };
    }

    try {
      console.log("[EYENEKA Pi] Calling Pi.authenticate(['username','payments']) first (no blocking fetch before)...");
      const auth = await withTimeout(
        window.Pi.authenticate(PI_AUTH_SCOPES, (incomplete) => {
          void handleIncompletePayment(incomplete);
        }),
        PI_WALLET_TIMEOUT_MS,
        () => new AuthTimeoutError(PI_POPUP_TIMEOUT_MESSAGE)
      );

      const accessToken = typeof auth?.accessToken === "string" ? auth.accessToken.trim() : "";
      const sdkUsername =
        typeof auth?.user?.username === "string"
          ? auth.user.username.trim().replace(/^@/, "")
          : "";
      const sdkUid = typeof auth?.user?.uid === "string" ? auth.user.uid.trim() : "";

      if (!accessToken && !sdkUsername) {
        return {
          success: false,
          result: null,
          error: PI_SIGNIN_ERROR_MESSAGE,
        };
      }

      paymentScopeAuthenticated = true;
      inMemoryUser = {
        uid: sdkUid || "pending-verify",
        username: sdkUsername || "Pioneer",
      };

      // Run /api/pi/login verification in the background AFTER Pi.authenticate succeeds
      if (accessToken) {
        void exchangeAccessTokenForSession(accessToken)
          .then((verified) => {
            inMemoryUser = verified.user;
            console.log("[EYENEKA Pi] Background session verified for:", verified.user.username);
          })
          .catch((bgErr) => {
            console.log("[EYENEKA Pi] Background /api/pi/login note:", bgErr);
          });
      }

      console.log("[EYENEKA Pi] Pi.authenticate succeeded:", inMemoryUser.username);
      return {
        success: true,
        result: {
          connected: true,
          username: inMemoryUser.username,
          uid: inMemoryUser.uid,
          kycVerified: Boolean(auth?.user?.kyc ?? true),
          inPiBrowser: true,
        },
      };
    } catch (err) {
      paymentScopeAuthenticated = false;
      console.log("[EYENEKA Pi] Pi.authenticate error:", err);
      const isTimeout = err instanceof AuthTimeoutError;
      const rawErr =
        err instanceof Error && err.message ? err.message : PI_SIGNIN_ERROR_MESSAGE;
      return {
        success: false,
        result: null,
        error: rawErr,
        timedOut: isTimeout,
      };
    } finally {
      authInFlight = null;
    }
  })();

  return await authInFlight;
}

export async function retryConnectPi(): Promise<PiAuthAttempt> {
  return await authenticateWithPiSdk({ fresh: true });
}

export async function executePiPayment(
  payload: PiPaymentPayload,
  onStatusChange?: (statusText: string) => void
): Promise<PiPaymentReceipt> {
  if (typeof window === "undefined" || !window.Pi) {
    throw new Error(PI_SDK_NOT_FOUND_MESSAGE);
  }

  const sdkReady = await initPiSdk();
  if (!sdkReady || !window.Pi) {
    throw new Error(lastInitError || PI_SDK_NOT_FOUND_MESSAGE);
  }

  onStatusChange?.("Connecting...");
  const authAttempt = await authenticateWithPiSdk();
  if (!authAttempt.success || !authAttempt.result) {
    throw new Error(authAttempt.error || PI_SIGNIN_ERROR_MESSAGE);
  }

  if (incompleteHandlingInFlight) {
    await withTimeout(incompleteHandlingInFlight, 8000, () => new Error("Incomplete cleanup wait")).catch(() => {
      // Proceed even if cleanup took longer than 8s
    });
  }

  const safeAmount = Number(Number(payload.amount).toFixed(2));
  if (!Number.isFinite(safeAmount) || safeAmount <= 0) {
    throw new Error("Invalid Pi payment amount. Must be greater than 0.");
  }
  const safeMemo =
    String(payload.memo || "Eyeneka Pi Payment")
      .trim()
      .slice(0, 120) || "Eyeneka Pi Payment";
  const safeMetadata: Record<string, string | number | boolean> = {};
  if (payload.metadata && typeof payload.metadata === "object") {
    for (const [k, v] of Object.entries(payload.metadata)) {
      const cleanKey = String(k).trim().slice(0, 50);
      if (!cleanKey) continue;
      if (typeof v === "string") {
        safeMetadata[cleanKey] = v.slice(0, 120);
      } else if (typeof v === "number" && Number.isFinite(v)) {
        safeMetadata[cleanKey] = v;
      } else if (typeof v === "boolean") {
        safeMetadata[cleanKey] = v;
      }
    }
  }
  if (Object.keys(safeMetadata).length === 0) {
    safeMetadata.type = "payment";
  }

  return await new Promise<PiPaymentReceipt>((resolve, reject) => {
    let settled = false;
    let walletTimer: number | null = window.setTimeout(() => {
      failOnce(new Error(PI_POPUP_TIMEOUT_MESSAGE));
    }, PI_WALLET_TIMEOUT_MS);

    const clearWalletTimer = () => {
      if (walletTimer !== null) {
        window.clearTimeout(walletTimer);
        walletTimer = null;
      }
    };

    const failOnce = (err: Error) => {
      clearWalletTimer();
      if (!settled) {
        settled = true;
        reject(err);
      }
    };

    try {
      const createPaymentStartMs = Date.now();
      console.log("[EYENEKA Pi] createPayment-start", {
        ts: createPaymentStartMs,
        amount: safeAmount,
        type: safeMetadata.type ?? "unknown",
      });
      onStatusChange?.("Waiting for Pi Wallet...");
      window.Pi!.createPayment(
        {
          amount: safeAmount,
          memo: safeMemo,
          metadata: safeMetadata,
        },
        {
          onReadyForServerApproval: async (paymentId) => {
            const approveStartMs = Date.now();
            const idPrefix = String(paymentId || "").slice(0, 8);
            console.log("[EYENEKA Pi] approve-start", {
              ts: approveStartMs,
              sinceCreateMs: approveStartMs - createPaymentStartMs,
              paymentIdPrefix: idPrefix,
            });
            clearWalletTimer();
            if (approvedOrInFlightPaymentIds.has(paymentId)) {
              console.warn("[EYENEKA Pi] Duplicate approve prevented for prefix:", idPrefix);
              return;
            }
            approvedOrInFlightPaymentIds.add(paymentId);
            onStatusChange?.("Waiting for Pi Wallet...");
            try {
              const res = await postJsonWithDetails("/api/pi/approve", {
                paymentId,
                clientApproveStartMs: approveStartMs,
              });
              console.log("[EYENEKA Pi] /api/pi/approve response:", {
                paymentIdPrefix: idPrefix,
                status: res.status,
                ok: res.ok,
                data: res.data,
              });
              if (!res.ok || res.data.ok === false) {
                approvedOrInFlightPaymentIds.delete(paymentId);
                failOnce(
                  new Error(
                    formatServerFailure(
                      "Pi approve failed",
                      res,
                      "Approval rejected by Pi Platform API"
                    )
                  )
                );
              }
            } catch (err: unknown) {
              approvedOrInFlightPaymentIds.delete(paymentId);
              console.log("[EYENEKA Pi] /api/pi/approve network error:", {
                paymentIdPrefix: idPrefix,
                err,
              });
              const msg = err instanceof Error ? err.message : String(err);
              failOnce(new Error(`Pi approve failed: 500 - ${msg}`));
            }
          },
          onReadyForServerCompletion: async (paymentId, txid) => {
            const completeStartMs = Date.now();
            const idPrefix = String(paymentId || "").slice(0, 8);
            clearWalletTimer();
            console.log("[EYENEKA Pi] complete-start", {
              ts: completeStartMs,
              paymentIdPrefix: idPrefix,
              hasTxid: Boolean(txid),
            });
            if (completedOrInFlightPaymentIds.has(paymentId)) {
              console.warn("[EYENEKA Pi] Duplicate complete prevented for prefix:", idPrefix);
              return;
            }
            completedOrInFlightPaymentIds.add(paymentId);
            onStatusChange?.("Confirming on Pi Testnet...");
            try {
              const res = await postJsonWithDetails("/api/pi/complete", {
                paymentId,
                txid,
              });
              console.log("[EYENEKA Pi] /api/pi/complete response:", {
                paymentIdPrefix: idPrefix,
                status: res.status,
                ok: res.ok,
                data: res.data,
              });
              if (!res.ok || res.data.ok === false) {
                completedOrInFlightPaymentIds.delete(paymentId);
                failOnce(
                  new Error(
                    formatServerFailure(
                      "Pi complete failed",
                      res,
                      "Completion rejected by Pi Platform API"
                    )
                  )
                );
                return;
              }
              onStatusChange?.("Payment Complete");
              if (!settled) {
                settled = true;
                resolve({
                  paymentId,
                  txHash: txid,
                  amount: safeAmount,
                  memo: safeMemo,
                  mode: "testnet-sdk",
                  status: "Confirmed",
                  grantIssued: res.data.grantIssued !== false,
                });
              }
            } catch (err: unknown) {
              completedOrInFlightPaymentIds.delete(paymentId);
              console.log("[EYENEKA Pi] /api/pi/complete network error:", {
                paymentIdPrefix: idPrefix,
                err,
              });
              const msg = err instanceof Error ? err.message : String(err);
              failOnce(new Error(`Pi complete failed: 500 - ${msg}`));
            }
          },
          onCancel: (paymentId) => {
            console.log("[EYENEKA Pi] onCancel paymentIdPrefix:", String(paymentId || "").slice(0, 8));
            failOnce(new PiPaymentCancelledError());
          },
          onError: (error, payment) => {
            console.log("[EYENEKA Pi] onError:", { error, payment });
            const rawMsg =
              error instanceof Error
                ? error.message
                : typeof error === "string"
                ? error
                : JSON.stringify(error ?? "Unknown Pi SDK error");
            failOnce(new Error(rawMsg));
          },
        }
      );
    } catch (err: unknown) {
      console.log("[EYENEKA Pi] createPayment threw synchronously:", err);
      const rawMsg = err instanceof Error ? err.message : String(err);
      failOnce(new Error(rawMsg));
    }
  });
}

export async function payUserToApp(
  onStatusChange?: (statusText: string) => void
): Promise<PiPaymentReceipt> {
  return await executePiPayment(
    {
      amount: 1,
      memo: "Eyeneka - Test Payment",
      metadata: { type: "test_payment" },
    },
    onStatusChange
  );
}

export async function triggerPiAd(
  adType: "interstitial" | "rewarded"
): Promise<{ completed: boolean; mode: string }> {
  if (typeof window !== "undefined" && window.Pi?.Ads) {
    try {
      const res = await window.Pi.Ads.showAd(adType);
      return {
        completed: res.result === "AD_REWARDED" || res.result === "AD_CLOSED",
        mode: "pi-ads-sdk",
      };
    } catch {
      // Ad runtime unavailable outside Pi Browser
    }
  }
  return { completed: false, mode: "unavailable" };
}
